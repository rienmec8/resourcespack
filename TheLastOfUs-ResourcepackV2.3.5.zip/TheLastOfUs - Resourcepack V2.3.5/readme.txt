TheLastOfUs - Resourcepack (version: 2.3.5)


This pack is meant for Minecrafts' Creative mode.

Place "TheLastOfUs - Resourcepack V2.3.5" in: AppData > Roaming > .minecraft > resourcepacks

Original download on www.planetminecraft.com - Anywhere else is fake!


The Last of Us� is a game made by Naughty Dog� - all rights reserved. 